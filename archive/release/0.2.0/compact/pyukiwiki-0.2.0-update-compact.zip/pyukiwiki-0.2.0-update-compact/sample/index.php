<?php
// PyukiWiki PHP wrapper sample
// $Id: index.php,v 1.199 2011/12/31 13:06:12 papu Exp $
// Code: EUC-JP
// URL���ѹ�
define('LOCATION', "http://pyukiwiki.sourceforge.jp/cgi-bin/wiki.cgi");
/////////////////////////////////////////////////
// QUERY_STRING����� from PukiWiki
$arg = '';
if (isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING']) {
	$arg = & $_SERVER['QUERY_STRING'];
} else if (isset($_SERVER['argv']) && ! empty($_SERVER['argv'])) {
	$arg = & $_SERVER['argv'][0];
}
if($arg == "") {
	$url=LOCATION;
} else {
	$url=LOCATION . '?' . $arg;
}
header('HTTP/1.1 302 Moved Temporarily');
header("Location: $url");
?>
