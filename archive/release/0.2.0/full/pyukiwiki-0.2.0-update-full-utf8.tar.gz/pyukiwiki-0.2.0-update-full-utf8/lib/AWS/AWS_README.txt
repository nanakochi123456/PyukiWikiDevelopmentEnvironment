こちらのperlモジュールは、アクセス解析に使用する
AWStats 日本語版を更に改造したものです。

http://awstats.sourceforge.net/
http://www.starplatinum.jp/awstats/awstats70/
