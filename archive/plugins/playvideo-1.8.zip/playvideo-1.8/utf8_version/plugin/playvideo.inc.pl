############################################################
# playvideo plugin
# playvideo.inc.pl
# Copyright(c) 2011 Nanami.
# for PyukiWiki 0.1.7 (http://nanakochi.daiba.cx/)
#
# 2011/06/12 change: flv動画にも対応した。ただし、wmvも必要です。
# 2011/05/26 change: wmvにタグが付けられている場合、zipファイルのダウンロード
#                    ファイル名をその名前に指定できるようにした。
# 2011/05/26 change: info/setup.cgiに対応した
# 2011/03/14 change: Content-disposition: attachment; filename="$file.wvx"
#                    を出力すると問題がある可能性があるため、出力を
#                    抑制した。
# 2011/03/01 change: 拡張子をwvxに変更した。
#                    Content-Type: video/x-ms-wvx を出力した。
#                    Content-disposition: attachment; filename="$file.wvx"
#                    を出力した。
# 2010/12/10 change: ニコニコ動画に対応した。
# 2010/12/10 change: ニコニコ動画に対応した
# 2010/11/13 change: 無圧縮zipでダウンロードできるようにした。
#                    大量の動画があるときキャッシュから取得するように
#                    した。ただし、有効期限は１時間です。
# 2010/10/27 change: MSIE とOpera以外はWindwos Mediaプレイヤー
#                    再生時に_blank(実質別タブ）になるようにした。
#                    Safariでは本当に別窓になります。
# 2010/10/24 change: use sub make_link_target
#
# 1TAB=4Spaces

use Nana::Cache;
use Image::ExifTool;
require "plugin/counter.inc.pl";

$::playvideo_plugin_usedownload=1		# 使わない時は0にする。
	if(!defined($::playvideo_plugin_usedownload));
$::playvideo_plugin_zipflags="-0";
$::playvideo_plugin_ziptmp="/tmp"
	if(!defined($::playvideo_plugin_ziptmp));
$::playvideo_plugin_videopath="video"
	if(!defined($::playvideo_plugin_videopath));
$::playvideo_plugin_playsite="http://$ENV{HTTP_HOST}/v.cgi"
	if(!defined($::playvideo_plugin_playsite));
$::playvideo_plugin_videourl="http://$ENV{HTTP_HOST}/$::playvideo_plugin_videopath"
	if(!defined($::playvideo_plugin_videourl));
# wmvのタイトルをzipに埋め込む
$::playvideo_plugin_downloadfilename_inwmv=0
	if(!defined($::playvideo_plugin_downloadfilename_inwmv));
# wmvの作者をzipに埋め込む
$::playvideo_plugin_downloadfilename_inwmv_withauthor=0
	if(!defined($::playvideo_plugin_downloadfilename_inwmv_withauthor));

$::playvideo_plugin_zipcmds=<<EOM;
/usr/bin/zip
/usr/local/bin/zip
EOM

sub plugin_playvideo_inline {
	my ($arg)=@_;
	my ($fname,$youtube,$nicovideo)=split(/,/,$arg);
	my $body;

	$videopath=$::playvideo_plugin_videopath;
	$playsite=$::playvideo_plugin_playsite;
	$videourl=$::playvideo_plugin_videourl;
	$fname=~s/\..*//g;
	$wmv="wmv";
	$ext="wvx";
	$zip="zip";
	$flv="flv";

	my $browser=$ENV{HTTP_USER_AGENT};
	my $wmvtarget = "";
	if ($browser=~/MSIE/ || $browser=~/Opera/ ) { 
	} else {
		$wmvtarget = "_blank";
	}

	my $cache=new Nana::Cache (
		ext=>"playvideo",
		files=>500,
		dir=>$::cache_dir,
		size=>100000,
		use=>1,
		expire=>1000000000000000
	);
	my $cachefile="playvideo_$fname";
	my $buf=$cache->read($cachefile,1);
	if($buf eq '') {
		my $exifTool = new Image::ExifTool;
		my $info = $exifTool->ImageInfo("$videopath/$fname.$wmv");
		my $title=&Jcode::convert($$info{Title}, 'sjis', 'utf8');
		my $author=&Jcode::convert($$info{Author}, 'sjis', 'utf8');
		my $copyright=&Jcode::convert($$info{Copyright}, 'sjis', 'utf8');
		$buf=<<EOM;
$$info{SendDuration}\t$title\t$author\t$copyright\t$$info{ImageWidth}\t$$info{ImageHeight}
EOM
		$cache->write($cachefile,$buf);
	}
	my ($time,$title,$author,$copyright,$width,$height)=split(/\t/,$buf);
	$body.=<<EOM;
<strong>
@{[&make_link_target("$playsite/$fname.$ext","",$wmvtarget,"Windows Media Player")]}
[Windows Media Player]</a></strong>
EOM
	if(-r "$videopath/$fname.$flv") {
		my $footer=40;
		$body.=<<EOM;
<a href="#" title="Flash" onclick="window.open('$playsite/$fname.$flv','_player','location=no,status=no,toolbar=no,hotkeys=no,directories=no,scrollbars=no,resizable=no,menubar=no,width=$width,height=@{[$height+$footer]}');return false;" onkeypress="window.open('$playsite/$fname.$flv','_player','location=no,status=no,toolbar=no,hotkeys=no,directories=no,scrollbars=no,resizable=no,menubar=no,width=$width,height=@{[$height+$footer]}');return false;">
[Flash]</a>
EOM
	}
	if($youtube ne '') {
		$body.=<<EOM;
@{[&make_link_target("$playsite/$fname.$youtube","","_blank","Youtube")]}
[Youtube]</a>
EOM
	}

	if($nicovideo ne '') {
		$body.=<<EOM;
@{[&make_link_target("$playsite/$fname.$nicovideo","","_blank","ニコニコ動画")]}
[ニコニコ動画]</a>
EOM
	}
	if($::playvideo_plugin_usedownload eq 1) {

		$body.=<<EOM;
@{[&make_link_target("$playsite/$fname.$zip","","","ダウンロード")]}
[ダウンロード]</a>
EOM
	}

	$body.=<<EOM;
($time)
<br />
EOM
	%vcounter=&plugin_counter_do("playvideo_$fname","r");
	$body.=<<EOM;
<span style="font-size: 10px;">
TOTAL: $vcounter{total} TODAY: $vcounter{today} YESTERDAY:$vcounter{yesterday}
</span>
EOM

	return $body;
}
1;
