######################################################################
# plugin for skin of sfdev.skin.??.cgi
# on MenuBar
# &sfdev;
######################################################################

sub plugin_sfdev_inline
{
	my ($args) = @_;
	return plugin_sfdev_convert($args);
}

sub plugin_sfdev_convert
{
	return '<dfn> </dfn>';
}

1;
__END__
