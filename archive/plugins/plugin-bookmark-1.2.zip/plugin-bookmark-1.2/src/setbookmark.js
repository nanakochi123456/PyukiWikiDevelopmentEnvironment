function setbookmark(u,t) {
	u=decodeURIComponent(u);
	t=decodeURIComponent(t);
	if(d.all) {
		window.external.AddFavorite(u,t);
	} else if(navigator.userAgent.indexOf("Firefox") != -1) {
		window.sidebar.addPanel(t,u,'');
	}
}
