/* "PyukiWiki" version 0.2.0-alpha13 $$ */
/* $Id: passwd.js,v 1.6 2011/08/24 05:03:09 papu Exp $ */

function pencode(c,b,d){var a;if(c.value==""){return}b.value=penc(utf16to8(c.value),utf16to8(d.value));c.value=""}function penc(g,f){var e,a,d,c;var b=f;c=Math.floor(Math.random()*127);d=b.substr(c/16,1)+b.substr(c%16,1);for(e=0;e<g.length;e++){a=g.charCodeAt(e)+c;d=d+b.substr(a/16,1)+b.substr(a%16,1)}return d}function utf16to8(e){var b,d,a,f;b="";a=e.length;for(d=0;d<a;d++){f=e.charCodeAt(d);if((f>=1)&&(f<=127)){b+=e.charAt(d)}else{if(f>2047){b+=String.fromCharCode(224|((f>>12)&15));b+=String.fromCharCode(128|((f>>6)&63));b+=String.fromCharCode(128|((f>>0)&63))}else{b+=String.fromCharCode(192|((f>>6)&31));b+=String.fromCharCode(128|((f>>0)&63))}}}return b};
