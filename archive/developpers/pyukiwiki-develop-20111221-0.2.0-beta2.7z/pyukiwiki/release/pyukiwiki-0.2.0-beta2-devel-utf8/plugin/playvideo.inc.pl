############################################################
# playvideo plugin
# playvideo.inc.pl
# Copyright(c) 2010 Nanami.
# for PyukiWiki 0.1.7 (http://nanakochi.daiba.cx/)
#
# 2010/12/10 change: ニコニコ動画に対応した
# 2010/11/13 change: 無圧縮zipでダウンロードできるようにした。
#                    大量の動画があるときキャッシュから取得するように
#                    した。ただし、有効期限は１時間です。
# 2010/10/27 change: MSIE とOpera以外はWindwos Mediaプレイヤー
#                    再生時に_blank(実質別タブ）になるようにした。
#                    Safariでは本当に別窓になります。
# 2010/10/24 change: use sub make_link_target
#
# 1TAB=4Spaces

use Nana::Cache;
use Image::ExifTool;
require "plugin/counter.inc.pl";

$playvideo_plugin_usedownload=1;	# 使わない時は0にする。
$playvideo_plugin_zipcmds=<<EOM;
/usr/bin/zip
/usr/local/bin/zip
EOM
$playvideo_plugin_zipflags="-0";
$playvideo_plugin_ziptmp="/tmp";
$playvideo_plugin_videopath="videonanakochi";
$playvideo_plugin_playsite="http://$ENV{HTTP_HOST}/v.cgi";
$playvideo_plugin_videourl="http://v.nanakochi.daiba.cx";

sub plugin_playvideo_convert {
	return &plugin_playvideo_inline(@_);
}

sub plugin_playvideo_inline {
	my ($arg)=@_;
	my ($fname,$youtube,$nicovideo)=split(/,/,$arg);
	my $body;

	$videopath=$playvideo_plugin_videopath;
	$playsite=$playvideo_plugin_playsite;
	$videourl=$playvideo_plugin_videourl;
	$fname=~s/\..*//g;
	$wmv="wmv";
	$ext="wvx";
	$zip="zip";

	my $browser=$ENV{HTTP_USER_AGENT};
	my $wmvtarget = "";
	if ($browser=~/MSIE/ || $browser=~/Opera/ ) {
	} else {
		$wmvtarget = "_blank";
	}
	$body.=<<EOM;
<strong>
@{[&make_link_target("$playsite/$fname.$ext","",$wmvtarget,"Windows Media Playerで再生")]}
[Windows Media Playerで再生]</a></strong>
EOM
	if($youtube ne '') {
		$body.=<<EOM;
@{[&make_link_target("$playsite/$fname.$youtube","","_blank","Youtubeで再生")]}
[Youtubeで再生]</a>
EOM
	}

	if($nicovideo ne '') {
		$body.=<<EOM;
@{[&make_link_target("$playsite/$fname.$nicovideo","","_blank","ニコニコ動画で再生")]}
[ニコニコ動画で再生]</a>
EOM
	}
	if($playvideo_plugin_usedownload eq 1) {

		$body.=<<EOM;
@{[&make_link_target("$playsite/$fname.$zip","","","ダウンロード")]}
[ダウンロード]</a>
EOM
	}

	my $cache=new Nana::Cache (
		ext=>"playvideo",
		files=>500,
		dir=>$::cache_dir,
		size=>100000,
		use=>1,
		expire=>3600
	);
	my $cachefile="playvideo_$fname";
	my $buf=$cache->read($cachefile,1);
	if($buf eq '') {
		my $exifTool = new Image::ExifTool;
		my $info = $exifTool->ImageInfo("$videopath/$fname.$wmv");
		my $title=&Jcode::convert($$info{Title}, 'sjis', 'utf8');
		my $author=&Jcode::convert($$info{Author}, 'sjis', 'utf8');
		my $copyright=&Jcode::convert($$info{Copyright}, 'sjis', 'utf8');
		$buf=<<EOM;
$$info{SendDuration},$title,$author,$copyright
EOM
		$cache->write($cachefile,$buf);
	}
	my ($time,$title,$author,$copyright)=split(/,/,$buf);
	$body.=<<EOM;
($time)
<br />
EOM
	%vcounter=&plugin_counter_do("playvideo_$fname","r");
	$body.=<<EOM;
<span style="font-size: 10px;">
TOTAL: $vcounter{total} TODAY: $vcounter{today} YESTERDAY:$vcounter{yesterday}
</span>
EOM

	return $body;
}
1;
