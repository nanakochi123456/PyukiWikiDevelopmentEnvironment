######################################################################
# GoogleSitemaps.pm - This is PyukiWiki, yet another Wiki clone.
# $Id: GoogleSitemaps.pm,v 1.3 2010/08/30 09:09:13 papu Exp $
#
# "Nana::GoogleSitemaps" version 0.1 $$
# Author: Nanami
# http://www.daiba.cx/
# Copyright (C) 2004-2006 by Nekyo.
# http://nekyo.qp.land.to/
# Copyright (C) 2005-2006 PyukiWiki Developers Team
# http://pyukiwiki.sourceforge.jp/
# Based on YukiWiki http://www.hyuki.com/yukiwiki/
# Powerd by PukiWiki http://pukiwiki.sourceforge.jp/
# License: GPL2 and/or Artistic or each later version
#
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
# Return Code:LF Japanese Code=EUC 1TAB=4Spaces
######################################################################

package Nana::GoogleSitemaps;
use strict;
use vars qw($VERSION);

$VERSION = '0.1';

# The constructor.
sub new {
	my ($class, %hash) = @_;
	my $self = {
		version => $hash{version},
		encoding => $hash{encoding},
		channel => { },
		items => [],
	};
	return bless $self, $class;
}

# Setting channel.
sub channel {
	my ($self, %hash) = @_;
	foreach (keys %hash) {
		$self->{channel}->{$_} = $hash{$_};
	}
	return $self->{channel};
}

# Adding item.
sub add_item {
	my ($self, %hash) = @_;
	push(@{$self->{items}}, \%hash);
	return $self->{items};
}

# 
sub as_string {
	my ($self) = @_;
	my $doc = <<"EOD";
<?xml version="1.0" encoding="UTF-8"?> 
<urlset
  xmlns="http://www.google.com/schemas/sitemap/0.84"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.google.com/schemas/sitemap/0.84
                      http://www.google.com/schemas/sitemap/0.84/sitemap.xsd">

@{[
 map {
  qq{
   <url>
   <loc>$_->{link}</loc>
   <lastmod>$_->{dc_date}</lastmod>
   <priority>$_->{priority}</priority> 
   </url>
  }
  } @{$self->{items}}
]}
</urlset>
EOD
}

1;
__END__
