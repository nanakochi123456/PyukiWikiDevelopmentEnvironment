/*/////////////////////////////////////////////////////////////////////
# @@HEADER2_NANAMI@@
/////////////////////////////////////////////////////////////////////*/

function allcheckbox(v) {
	f=d.getElementById("sel");
	len=f.elements.length;
	for(i=0;i<len;i++) {
		if(f.elements[i].type == "checkbox") {
			if(v == 1) {
				if(!f.elements[i].checked) {
					f.elements[i].click();
				}
			} else {
				if(f.elements[i].checked) {
					f.elements[i].click();
				}
			}
		}
	}
}
