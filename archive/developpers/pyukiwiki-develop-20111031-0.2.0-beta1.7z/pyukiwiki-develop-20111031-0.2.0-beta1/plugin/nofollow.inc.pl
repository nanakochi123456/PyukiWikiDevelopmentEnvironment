######################################################################
# @@HEADER2_NANAMI@@
######################################################################
# This is dummy plugin for PukiWiki compatibility
######################################################################

sub plugin_nofollow_convert {
	return ' ';
}

1;
__END__

=head1 NAME

nofollow.inc.pl - PyukiWiki Plugin

=head1 SYNOPSIS

 #nofollow

=head1 DESCRIPTION

It is dummy plug-in for compatibility with PukiWiki. It may be used in the future.

=head1 SEE ALSO

=over 4

=item PyukiWiki/Plugin/Standard/nofollow

L<@@BASEURL@@/PyukiWiki/Plugin/Standard/nofollow/>

=item PyukiWiki CVS

L<@@CVSURL@@/PyukiWiki-Devel/plugin/nofollow.inc.pl>

=back

=head1 AUTHOR

=over 4

@@AUTHOR_NANAMI@@

@@AUTHOR_PYUKI@@

=back

=head1 LICENSE

@@LICENSE_NANAMI@@

=cut
