######################################################################
# @@HEADER2_NANAMI@@
######################################################################
# google sitemaps
# based on PukiWiki Google Sitemaps by Terai Atsuhiro
# http://terai.xrea.jp/PukiWiki/Google.html
# http://www.google.com/webmasters/sitemaps/login
######################################################################

use Nana::GoogleSitemaps;

sub plugin_sitemaps_action {
	my $sitemaps = new Nana::GoogleSitemaps(
		version => '1.0',
		encoding => "UTF-8",
	);
	my $recentchanges = $::database{$::RecentChanges};
	my $count = 0;
	foreach (split(/\n/, $recentchanges)) {
		last if ($count >= 10000);
		/^\- (\d\d\d\d\-\d\d\-\d\d) \(...\) (\d\d:\d\d:\d\d) (.*?)\ \ \-/;    # data format.
		my $title = &unarmor_name($3);
		my $escaped_title = &escape($title);
		my $link = $modifier_rss_link . &make_cookedurl($title);
		my $description = $escaped_title . &escape(&get_subjectline($title));

		$gmt = ((localtime(time))[2] + (localtime(time))[3] * 24)
			- ((gmtime(time))[2] + (gmtime(time))[3] * 24);
		my $date = $1 . "T" . $2 . sprintf("%+02d:00", $gmt);

		$link=~s!://!\t!g;
		$link=~s!//!/!g;
		$link=~s!\t!://!g;

		if(&is_readable($title) && $title!~/$::non_list/) {
			$sitemaps->add_item(
				title => $escaped_title,
				link  => $link,
				dc_date => $date,
				priority=>"1.0"
			);
			$count++;
		}
	}
	# print RSS information (as XML).
	my $body=$sitemaps->as_string;
	if($::lang eq 'ja') {
		$body=&code_convert(\$body, 'utf8');
	}
	print &http_header("Content-type: text/xml");
	print $body;
	&close_db;
	exit;
}
1;
__END__
