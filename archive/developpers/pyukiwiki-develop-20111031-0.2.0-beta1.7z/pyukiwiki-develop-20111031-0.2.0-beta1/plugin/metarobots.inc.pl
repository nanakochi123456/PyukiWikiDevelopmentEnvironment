######################################################################
# @@HEADER2_NANAMI@@
######################################################################
# v0.2.0 First Release
#
#*Usage
# #metarobots(keywords,[keywords]...)
# #metarobots(disable)
######################################################################

sub plugin_metarobots_convert {
	my ($arg)=@_;
	return if(!&is_frozen($::form{mypage}));
	return ' ' if($arg eq '');
	my $keyword;
	my $noarchiveflg=0;
	foreach(split(/,/,$arg)) {
		if(/^noarchive$/) {
			$noarchiveflg=1;
			next;
		}
		$keyword.="$_,";
	}
	$keyword=~s/\,$//g;
	if($keyword eq "disable") {
		$::IN_META_ROBOTS=<<EOM;
<meta name="robots" content="NOINDEX,NOFOLLOW,NOARCHIVE" />
<meta name="googlebot" content="NOINDEX,NOFOLLOW,NOARCHIVE" />
EOM
	} elsif($noarchiveflg eq 1) {
		$::IN_META_ROBOTS=<<EOM;
<meta name="robots" content="INDEX,FOLLOW,NOARCHIVE" />
<meta name="googlebot" content="INDEX,FOLLOW,NOARCHIVE" />
<meta name="keywords" content="$keyword" />
EOM
	} else {
		$::IN_META_ROBOTS=<<EOM;
<meta name="robots" content="INDEX,FOLLOW" />
<meta name="googlebot" content="INDEX,FOLLOW,ARCHIVE" />
<meta name="keywords" content="$keyword" />
EOM
	}
	return ' ';
}
1;
__END__

=head1 NAME

metarobots.inc.pl - PyukiWiki Plugin

=head1 SYNOPSIS

 #metarobots(keywords [,keywords]...[,noarchive])
 #metarobots(disable)

=head1 DESCRIPTION

Setting metarobots tag

=head1 SEE ALSO

=over 4

=item PyukiWiki/Plugin/Standard/metarobots

L<@@BASEURL@@/PyukiWiki/Plugin/Standard/metarobots/>

=item PyukiWiki CVS

L<@@CVSURL@@/PyukiWiki-Devel/plugin/metarobots.inc.pl>

=back

=head1 AUTHOR

=over 4

@@AUTHOR_NANAMI@@

@@AUTHOR_PYUKI@@

=back

=head1 LICENSE

@@LICENSE_NANAMI@@

=cut
