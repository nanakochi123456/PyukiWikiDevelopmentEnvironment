######################################################################
# @@HEADER2_NANAMI@@
######################################################################
# This is extented plugin.
# To use this plugin, rename to 'setting.inc.cgi'
######################################################################

# Initlize											# comment

%::setting_cookie;
$::setting_cookie="PWS_"
				. &dbmname($::basepath);
%::name_cookie;
$::name_cookie="PWU_"
				. &dbmname($::basepath);

sub plugin_setting_init {
	&exec_explugin_sub("lang");
	&exec_explugin_sub("urlhack");
	if($::navi{"setting_url"} eq '') {
		push(@::addnavi,"setting:help");
		$::navi{"setting_url"}="$::script?cmd=setting&amp;mypage=@{[&encode($::form{mypage} ne '' ? $::form{mypage} : $::form{refer})]}";
		$::navi{"setting_name"}=$::resource{"settingbutton"};
		$::navi{"setting_type"}="plugin";
	}
	%::setting_cookie=();
	%::setting_cookie=&getcookie($::setting_cookie,%::setting_cookie);
	%::name_cookie=&getcookie($::name_cookie,%::name_cookie);
	if($::setting_cookie{savename} eq 0) {
		if($::name_cookie{myname} ne '') {
			$::name_cookie{myname}="";
			&setcookie($::name_cookie, -1, %::name_cookie);
		}
	}
	&plugin_setting_setting;
	return ('init'=>1);
}

sub plugin_setting_savename {
	my($name)=@_;
	$::name_cookie{myname}=$name;
	&setcookie($::name_cookie, 1, %::name_cookie);
}

sub plugin_setting_setting {
	if($::setting_cookie{style} ne '') {
		my $style=$::setting_cookie{style};
		if($style!~/\//) {
			my $push=$::skin_name;
			$::skin_name=$style;
			&skin_init;
			$::skin_name=$push;
		}
	}
	if($::setting_cookie{fontsize}+0 > 0) {
		$::IN_HEAD.=<<EOM
<style type="text/css"><!--
#body {
	font-size: @{[$::setting_cookie{fontsize} eq 1 ? '120' : '80']}%;
}
//--></style>
EOM
	}
}
1;
__DATA__
sub plugin_setting_setup {
	return(
	'ja'=>'cookie���Ф���Wiki��ɽ������򤹤�',
	'en'=>'Setup of Wiki is carried out to cookie.',
	'url'=>'http://pyukiwiki.sourceforge.jp/PyukiWiki/Plugin/Admin/setting/'
	);
__END__

=head1 NAME

setting.inc.pl - PyukiWiki ExPlugin

=head1 SYNOPSIS

This is plugin/setting.inc.pl 's sub plugin, look plugin document.

=head1 SEE ALSO

=over 4

=item PyukiWiki/Plugin/Admin/setting

L<@@BASEURL@@/PyukiWiki/Plugin/ExPlugin/punyurl/>

=item PyukiWiki CVS

L<@@CVSURL@@/PyukiWiki-Devel/lib/setting.inc.pl>

L<@@CVSURL@@/PyukiWiki-Devel/plugin/setting.inc.pl>

=back

=head1 AUTHOR

@@AUTHOR_NANAMI@@

@@AUTHOR_PYUKI@@

=head1 LICENSE

@@LICENSE_NANAMI@@

=cut
