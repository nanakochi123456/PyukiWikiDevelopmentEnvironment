function sethomepage(u,t){
	u=decodeURIComponent(u);
	t=decodeURIComponent(t);
	var ua = navigator.userAgent;
	var ie = ua.indexOf("MSIE");
	var iever = parseInt(ua.substring(ie+5,ie+6,ie+7,ie+8,ie+9));
	var os = ua.indexOf("Windows");
	if (d.all){
		if(ie > 0 && iever >= 5 && os > 0){
			d.body.style.behavior = "url('#default#homepage')";
			d.body.setHomePage(u);
		}else{
			window.external.AddFavorite(u,t);
		}
	}
}
