######################################################################
# sitemaps.inc.pl - This is PyukiWiki, yet another Wiki clone.
# $Id$
#
# "PyukiWiki" version 0.2.0 $$
# Author: Nanami http://nanakochi.daiba.cx/
# Copyright (C) 2004-2012 by Nekyo.
# http://nekyo.qp.land.to/
# Copyright (C) 2005-2012 PyukiWiki Developers Team
# http://pyukiwiki.sfjp.jp/
# Based on YukiWiki http://www.hyuki.com/yukiwiki/
# Powerd by PukiWiki http://pukiwiki.sfjp.jp/
# License: GPL2 and/or Artistic or each later version
#
# This program is free software; you can redistribute it and/or
# modify it under the same terms as Perl itself.
# Return:LF Code=EUC-JP 1TAB=4Spaces
######################################################################
# google sitemaps
# based on PukiWiki Google Sitemaps by Terai Atsuhiro
# http://terai.xrea.jp/PukiWiki/Google.html
# http://www.google.com/webmasters/sitemaps/login
######################################################################

use Nana::GoogleSitemaps;

sub plugin_sitemaps_action {
	my $sitemaps = new Nana::GoogleSitemaps(
		version => '1.0',
		encoding => "UTF-8",
	);
	my $recentchanges = $::database{$::RecentChanges};
	my $count = 0;
	foreach (split(/\n/, $recentchanges)) {
		last if ($count >= 10000);
		/^\- (\d\d\d\d\-\d\d\-\d\d) \(...\) (\d\d:\d\d:\d\d) (.*?)\ \ \-/;    # data format.
		my $title = &unarmor_name($3);
		my $escaped_title = &escape($title);
		my $link = $modifier_rss_link . &make_cookedurl($title);
		my $description = $escaped_title . &escape(&get_subjectline($title));

		$gmt = ((localtime(time))[2] + (localtime(time))[3] * 24)
			- ((gmtime(time))[2] + (gmtime(time))[3] * 24);
		my $date = $1 . "T" . $2 . sprintf("%+02d:00", $gmt);

		$link=~s!://!\t!g;
		$link=~s!//!/!g;
		$link=~s!\t!://!g;

		if(&is_readable($title) && $title!~/$::non_list/) {
			$sitemaps->add_item(
				title => $escaped_title,
				link  => $link,
				dc_date => $date,
				priority=>"1.0"
			);
			$count++;
		}
	}
	# print RSS information (as XML).
	my $body=$sitemaps->as_string;
	if($::lang eq 'ja') {
		$body=&code_convert(\$body, 'utf8');
	}
	print &http_header("Content-type: text/xml");
	print $body;
	&close_db;
	exit;
}
1;
__END__
