######################################################################
# @@HEADER2_NEKYO@@
######################################################################
# Usage:?cmd=source&page=pagename
######################################################################

use strict;
sub plugin_source_action {
	return if ($::form{'page'} eq '');
	my $page = $::form{'page'};
	print "Content-Type: text/plain\r\n\r\n";
	print $::database{$page};
	&close_db;
	exit(0);
}
1;
__END__

=head1 NAME

source.inc.pl - PyukiWiki Plugin

=head1 AUTHOR

=over 4

@@AUTHOR_NEKYO@@

@@AUTHOR_PYUKI@@

=back

=head1 LICENSE

@@LICENSE_NEKYO@@

=cut
