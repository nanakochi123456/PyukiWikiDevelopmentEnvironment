######################################################################
# title.inc.pl - This is PyukiWiki, yet another Wiki clone.
# $Id$
#
# "PyukiWiki" version 0.2.0-alpha1 $$
# Author: Nanami http://nanakochi.daiba.cx/
# Copyright (C) 2004-2011 by Nekyo.
# http://nekyo.qp.land.to/
# Copyright (C) 2005-2011 PyukiWiki Developers Team
# http://pyukiwiki.sourceforge.jp/
# Return:LF Code=EUC-JP 1TAB=4Spaces
######################################################################
# v0.2.0 First Release
#
#*Usage
# #title(title tag string)
######################################################################


sub plugin_title_convert {
	my ($title) = shift;
	return if(!&is_frozen($::form{mypage}));
	$::IN_TITLE=&htmlspecialchars($title);
	return ' ';
}
1;
__END__

